#include <iostream>

using namespace std;

int main (int argc, char const *argv[]){
    // argc is the number of string given to this program
    //agrv is the array of strings
    cout<<"Hello, World!"<<endl;
    //This is a comment
    /*
    this is a multiline comment
    */
    int x = 3;
    cout<<"The number x is "<<x<<endl;
    int y;
    cout<<"Please enter a number of y: ";
    cin>>y;
    cout<<"The number y is "<<y<<endl; 
    /*
    Data types in C++ are:
         int, float, double, bool, and char(one character only)

    */
    int a;
    cout<<"The value of a is "<<a<<endl;
    



}